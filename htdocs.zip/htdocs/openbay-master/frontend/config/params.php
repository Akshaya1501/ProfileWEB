<?php
return [
    'adminEmail' => 'admin@example.com',
    'torrentFilesServer' => 'http://torrent.oldpiratebay.org',
    'numberComplaintsToHide' => 3
];
