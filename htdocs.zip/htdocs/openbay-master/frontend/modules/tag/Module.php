<?php

namespace frontend\modules\tag;

class Module extends \yii\base\Module
{
    public $controllerNamespace = 'frontend\modules\tag\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
