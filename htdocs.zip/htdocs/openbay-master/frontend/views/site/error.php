<?php
/* @var $this yii\web\View */
/* @var $name string */
/* @var $message string */
/* @var $exception Exception */

$this->title = $name;
?>
<div class="not-found-ads">
    <a href="http://isoplex.isohunt.to/" class="img"><img src="/img/404.png" style="margin: 0 auto;"/></a>
</div>
