<?php
return [
    'adminEmail' => 'admin@example.com',
    'user.passwordResetTokenExpire' => 3600,
];
