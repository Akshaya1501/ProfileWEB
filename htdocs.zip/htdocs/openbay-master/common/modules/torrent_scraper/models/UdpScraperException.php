<?php
namespace common\modules\torrent_scraper\models;

class UdpScraperException extends ScraperException
{

}