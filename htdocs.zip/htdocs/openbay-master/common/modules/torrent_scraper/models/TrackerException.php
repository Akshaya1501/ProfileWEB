<?php

namespace common\modules\torrent_scraper\models;

class TrackerException extends \Exception
{

}