<?php
namespace common\modules\torrent_scraper\models;

class ScraperException extends \Exception
{

}