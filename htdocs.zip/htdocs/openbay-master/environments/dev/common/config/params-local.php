<?php
return [
    'name' => 'Open Pirate Bay',
    'supportEmail' => 'support@email.com',
];
