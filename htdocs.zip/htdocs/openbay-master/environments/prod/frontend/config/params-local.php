<?php
return [
    'name' => 'Open Pirate Bay',
    'numberComplaintsToHide' => 3
];