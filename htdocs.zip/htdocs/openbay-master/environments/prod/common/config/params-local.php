<?php
return [
    'supportEmail' => 'support@email.com',
];

